#pragma once
#include <stdint.h>

void idt_init(void);