#pragma once
#include <carlos/uapi/api.h>

extern const CarlosApi g_api;