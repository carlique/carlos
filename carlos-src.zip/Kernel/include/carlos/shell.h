#pragma once
#include <carlos/bootinfo.h>

void shell_run(const BootInfo *bi);