#include <stdint.h>
#include <carlos/shell.h>
#include <carlos/str.h>
#include <carlos/pmm.h>
#include <carlos/kbd.h>
#include <carlos/klog.h>
#include <carlos/uart.h>
#include <carlos/fbcon.h>
#include <carlos/time.h>
#include <carlos/pci.h>
#include <carlos/ahci.h>

static inline void outb(uint16_t port, uint8_t val){
  __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port){
  uint8_t r;
  __asm__ volatile ("inb %1, %0" : "=a"(r) : "Nd"(port));
  return r;
}

static const char* skip_ws(const char *s){
  while (s && (*s == ' ' || *s == '\t')) s++;
  return s;
}

static uint64_t parse_u64(const char *s){
  s = skip_ws(s);
  uint64_t v = 0;
  while (*s >= '0' && *s <= '9') {
    v = v * 10 + (uint64_t)(*s - '0');
    s++;
  }
  return v;
}

static int hexval(char c){
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return 10 + (c - 'a');
  if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
  return -1;
}

static int parse_hex_u8_1or2(const char *s, uint8_t *out, const char **end){
  int a = hexval(*s);
  if (a < 0) return -1;
  int b = hexval(*(s+1));
  if (b >= 0) { *out = (uint8_t)((a<<4) | b); if (end) *end = s+2; }
  else        { *out = (uint8_t)a;            if (end) *end = s+1; }
  return 0;
}

// Accept "00:1f.2" or "0:1f.2"
static int parse_bdf(const char *arg, uint8_t *bus, uint8_t *dev, uint8_t *fun){
  arg = skip_ws(arg);
  if (!arg || !*arg) return -1;

  const char *p = arg;
  if (parse_hex_u8_1or2(p, bus, &p) != 0) return -1;
  if (*p != ':') return -1;
  p++;

  if (parse_hex_u8_1or2(p, dev, &p) != 0) return -1;
  if (*p != '.') return -1;
  p++;

  int fv = hexval(*p);
  if (fv < 0) return -1;
  *fun = (uint8_t)fv;
  return 0;
}

static int parse_dec_u8(const char *s, uint8_t *out, const char **end){
  s = skip_ws(s);
  if (!s || *s < '0' || *s > '9') return -1;
  uint32_t v = 0;
  while (*s >= '0' && *s <= '9') { v = v*10 + (uint32_t)(*s - '0'); s++; }
  if (v > 255) return -1;
  *out = (uint8_t)v;
  if (end) *end = s;
  return 0;
}

static int parse_bdf_dec3(const char *arg, uint8_t *bus, uint8_t *dev, uint8_t *fun){
  const char *p = skip_ws(arg);
  if (!p || !*p) return -1;

  if (parse_dec_u8(p, bus, &p) != 0) return -1;
  p = skip_ws(p);
  if (!*p) return -1;

  if (parse_dec_u8(p, dev, &p) != 0) return -1;
  p = skip_ws(p);
  if (!*p) return -1;

  if (parse_dec_u8(p, fun, &p) != 0) return -1;

  // optional trailing whitespace only
  p = skip_ws(p);
  if (*p != 0) return -1;

  return 0;
}

static void hexdump_512(const void *p){
  const uint8_t *b = (const uint8_t*)p;
  for (int i=0;i<512;i+=16){
    kprintf("%p: ", (void*)(uintptr_t)(uint64_t)i);
    for (int j=0;j<16;j++){
      kprintf("%02x ", (uint32_t)b[i+j]);
    }
    kputs(" |");
    for (int j=0;j<16;j++){
      char c = (char)b[i+j];
      if (c < 32 || c > 126) c = '.';
      kputc(c);
    }
    kputs("|\n");
  }
}

static void cpu_halt_forever(void){
  for(;;) __asm__ volatile ("hlt");
}

static void prompt(void){
  kputs("carlos> ");
}

static void cmd_help(void){
  kputs("Commands:\n");
  kputs("  help   - this help\n");
  kputs("  mem    - show free pages\n");
  kputs("  alloc  - allocate one page\n");
  kputs("  clear  - clear screen\n");
  kputs("  halt   - stop CPU\n");
  kputs("  reboot - reboot machine\n");
  kputs("  pf      - trigger a page fault (test IDT)\n");
  kputs("  time    - show current time (ns)\n");
  kputs("  sleep N - sleep N milliseconds\n");
  kputs("  lspci   - list PCI devices\n");
  kputs("  pcidump BB:DD.F - dump PCI config of device\n");
  kputs("  ahci    - probe for AHCI controller\n");
  kputs("  ahci_read <port> <lba> [count] - read sectors via AHCI and hexdump\n");
}

static void cmd_mem(void){
  kprintf("free pages = %llu\n", pmm_free_count());
}

static void cmd_alloc(void){
  void *p = pmm_alloc_page();
  kprintf("alloc page = %p\n", p);
}

static void cmd_clear(void){
  // Clear framebuffer
  fbcon_clear();

  // Also clear the serial terminal (ANSI escape)
  uart_puts("\x1b[2J\x1b[H");
}

static void cmd_halt(void){
  kputs("halting.\n");
  for(;;) __asm__ volatile ("hlt");
}

static void cmd_reboot(void){
  kputs("rebooting...\n");

  __asm__ volatile ("cli");

  // Wait until input buffer is clear (bit 1 == 0)
  for (int i = 0; i < 100000; i++){
    if ((inb(0x64) & 0x02) == 0) break;
  }

  // Pulse CPU reset line via 8042 controller
  outb(0x64, 0xFE);

  // If it didn't reboot, just halt.
  cpu_halt_forever();
}

static void cmd_pf(void){
  kprintf("Triggering page fault...\n");
  volatile uint64_t *p = (volatile uint64_t*)0xDEADBEEF000ULL;
  *p = 1; // should fault -> #PF vec=14, CR2 = that address
}

static void cmd_time(void){
  kprintf("now_ns=%llu\n", time_now_ns());
}

static void cmd_sleep(const char *arg){
  uint64_t ms = parse_u64(arg);
  kprintf("sleep %llu ms...\n", ms);
  time_sleep_ms(ms);
  kprintf("done\n");
}

static void cmd_lspci(void){
  pci_list();
}

static void cmd_pcidump(const char *arg){
  uint8_t b=0,d=0,f=0;

  if (parse_bdf(arg, &b, &d, &f) != 0) {
    if (parse_bdf_dec3(arg, &b, &d, &f) != 0) {
      kprintf("usage: pcidump BB:DD.F  |  pcidump <bus> <dev> <fun>\n");
      return;
    }
  }

  pci_dump_bdf(b, d, f);
}

static void cmd_ahci(const char *arg){
  // v1: ignore arg and just auto-probe
  (void)arg;
  ahci_probe();
}

static void cmd_ahci_read(const char *arg){
  // usage: ahci_read <port> <lba> [count]
  uint8_t port = 0;
  uint64_t lba = 0;
  uint64_t cnt = 1;

  const char *p = skip_ws(arg);
  if (!p || !*p) { kputs("usage: ahci_read <port> <lba> [count]\n"); return; }

  // port (decimal u8)
  uint8_t pv=0; const char *e=0;
  if (parse_dec_u8(p, &pv, &e) != 0) { kputs("bad port\n"); return; }
  port = pv; p = skip_ws(e);

  // lba (decimal u64)
  lba = parse_u64(p);
  while (*p && *p != ' ' && *p != '\t') p++;
  p = skip_ws(p);

  // optional count
  if (p && *p) cnt = parse_u64(p);
  if (cnt == 0) cnt = 1;
  if (cnt > 8) cnt = 8; // keep it small for now

  // allocate buffer (one page is enough for up to 8 sectors = 4096 bytes)
  void *buf = pmm_alloc_page();
  if (!buf) { kputs("no mem\n"); return; }

  int rc = ahci_read(port, lba, (uint32_t)cnt, buf);
  kprintf("ahci_read rc=%d\n", (int64_t)rc);

  if (rc == 0){
    hexdump_512(buf);
  }

  pmm_free_page(buf);
}

static void run_cmd(char *line){
  if (!line) return;

  // Trim leading whitespace
  char *cmd = line;
  while (*cmd == ' ' || *cmd == '\t') cmd++;

  // If empty line, nothing to do
  if (*cmd == 0) return;

  // Split into cmd + arg (in-place)
  char *arg = 0;
  for (char *q = cmd; *q; q++){
    if (*q == ' ' || *q == '\t'){
      *q = 0;                 // terminate command token
      arg = q + 1;            // argument string (may have leading ws)
      break;
    }
  }
  if (arg) arg = (char*)skip_ws(arg);

  // Dispatch (always return after handling)
  if (kstreq(cmd, "help"))   { cmd_help();   return; }
  if (kstreq(cmd, "mem"))    { cmd_mem();    return; }
  if (kstreq(cmd, "alloc"))  { cmd_alloc();  return; }
  if (kstreq(cmd, "clear"))  { cmd_clear();  return; }
  if (kstreq(cmd, "halt"))   { cmd_halt();   return; }
  if (kstreq(cmd, "reboot")) { cmd_reboot(); return; }

  if (kstreq(cmd, "pf"))     { cmd_pf();     return; }
  if (kstreq(cmd, "time"))   { cmd_time();   return; }
  if (kstreq(cmd, "sleep"))  { cmd_sleep(arg); return; }

  if (kstreq(cmd, "lspci")) { cmd_lspci(); return; }
  if (kstreq(cmd, "pcidump")) { cmd_pcidump(arg); return; }
  if (kstreq(cmd, "ahci")) { cmd_ahci(arg); return; }
  if (kstreq(cmd, "ahci_read")) { cmd_ahci_read(arg); return; }

  kputs("unknown: ");
  kputs(cmd);
  kputs("\n");
}

void shell_run(const BootInfo *bi){
  
  (void)bi;

  kputs("Carlos shell ready. Type 'help'.\n");
  prompt();

  char line[128];
  int len = 0;

  kbd_init();

  while (1){
    char c;
    if (!kbd_try_getc(&c) && !uart_try_getc(&c)) continue;

    // Enter
    if (c == '\r' || c == '\n'){
      kputs("\n");          // <-- ensures a clean new line after Enter
      line[len] = 0;
      run_cmd(line);
      len = 0;
      prompt();
      continue;
    }

    // Backspace (0x08) or DEL (0x7F)
    if (c == 0x08 || c == 0x7F){
      if (len > 0){
        len--;
        // erase on terminal: back, space, back
        kputc('\b'); kputc(' '); kputc('\b');
      }
      continue;
    }

    // Printable ASCII
    if (c >= 0x20 && c <= 0x7E){
      if (len < (int)sizeof(line)-1){
        line[len++] = c;
        kputc(c); // echo
      }
      continue;
    }
  }
}