#pragma once
#include <Uefi.h>

VOID LogInit(VOID);
VOID Log(IN CONST CHAR16 *Msg);